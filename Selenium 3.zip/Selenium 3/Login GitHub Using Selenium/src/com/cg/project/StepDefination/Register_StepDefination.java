package com.cg.project.StepDefination;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Register_StepDefination 
{
	private WebDriver driver;
	
	@Given("^User wants to create new account for GitHub$")
	public void user_wants_to_create_new_account_for_GitHub() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@When("^User opens Google Chrome$")
	public void user_opens_Google_Chrome() throws Throwable {
	    driver.get("https://www.google.com/");
	}

	@Then("^searches for GitHub Registration Page$")
	public void searches_for_GitHub_Registration_Page() throws Throwable {
		driver.get("https://github.com/");
	}

	@When("^user clicks on new registration$")
	public void user_clicks_on_new_registration() throws Throwable {
	    driver.get("https://github.com/join?source=header");
	}

	@Then("^new Registration page is loaded$")
	public void new_Registration_page_is_loaded() throws Throwable {
	   driver.get("https://github.com/join?source=header-home");
	    
	}

	@When("^user entered all the details in the page$")
	public void user_entered_all_the_details_in_the_page() throws Throwable {
		 WebElement userName = driver.findElement(By.id("user_login"));
		 userName.sendKeys("RKJRserida123");
		 
		 WebElement email = driver.findElement(By.id("user_email"));
		 email.sendKeys("ramjuramiedaseri123@gmail.com");
		 
		 WebElement password = driver.findElement(By.id("user_password"));
		 password.sendKeys("RajeKumai@123");
		 
		 password.submit();
	    
	}

	@Then("^Successfull login page should be displayed$")
	public void successfull_login_page_should_be_displayed() throws Throwable {
	    System.out.println("Account created Successfully");
	}
	@When("^user clicks on continue button$")
	public void user_clicks_on_continue_button() throws Throwable {

		/*WebElement button = driver.findElement(By.tagName("button"));
		button.click();*/
		
		driver.findElements(By.className("button.btn.btn-primary.js-choose-plan-submit")).get(0).click();
	    
	}

	@Then("^go to next step$")
	public void go_to_next_step() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^reached last step$")
	public void reached_last_step() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^do final submit$")
	public void do_final_submit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
