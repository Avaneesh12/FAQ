package com.cg.project.StepDefination;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login_stepDefination 
{
	private WebDriver driver;
		
	@Given("^User open GitHub Login page on browser$")
	public void user_open_GitHub_Login_page_on_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		
	}

	@When("^User enter username 'ABC' and password 'hello'$")
	public void user_enter_username_ABC_and_password_hello() throws Throwable {
		WebElement userName = driver.findElement(By.id("login_field"));
		userName.sendKeys("ABC");
		
		WebElement passWord = driver.findElement(By.id("password"));
		passWord.sendKeys("hello");
		passWord.submit();
		
	}

	@Then("^Display 'Invalid Username' page$")
	public void display_Invalid_Username_page() throws Throwable {
		WebElement userName1 = driver.findElement(By.id("login_field"));
		userName1.clear();
		WebElement message = driver.findElement(By.id("js-flash-container"));
		String msg = message.getText();
		assertEquals("Incorrect username or password.", msg);
		
	}

	@When("^User enter username 'hello' and password 'ABC'$")
	public void user_enter_username_hello_and_password_ABC() throws Throwable {
		WebElement userName = driver.findElement(By.id("login_field"));
		userName.sendKeys("hello");
		WebElement passWord = driver.findElement(By.id("password"));
		passWord.sendKeys("ABC");
		passWord.submit();
		WebElement message = driver.findElement(By.id("js-flash-container"));
		String msg = message.getText();
		assertEquals("Incorrect username or password.", msg);
	}

	@When("^User enter username 'admin' and password 'hello'$")
	public void user_enter_username_admin_and_password_hello() throws Throwable {
		WebElement userName = driver.findElement(By.id("login_field"));
		userName.sendKeys("Ramesh");
		
		WebElement passWord = driver.findElement(By.id("password"));
		passWord.sendKeys("Hello");
		passWord.submit();
	}

	@Then("^Login Successfully done\\.$")
	public void login_Successfully_done() throws Throwable {
		System.out.println("Login Succesful");
		
	}

}
