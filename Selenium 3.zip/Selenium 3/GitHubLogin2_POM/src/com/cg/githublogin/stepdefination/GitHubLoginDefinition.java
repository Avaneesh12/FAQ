package com.cg.githublogin.stepdefination;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.githubloginPage.beans.LoginPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubLoginDefinition {

	private WebDriver driver;
	LoginPage loginPage;
	
	@Before
	public void setupStepEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		
	}
	
	@Given("^User is on GitHub login Page$")
	public void user_is_on_GitHub_login_Page() throws Throwable {
		driver = new ChromeDriver();
	    driver.get("https://github.com/login");
	    loginPage = new LoginPage();
	    PageFactory.initElements(driver, loginPage);
	}

	@When("^User enter Invalid username and password$")
	public void user_enter_Invalid_username_and_password() throws Throwable {
	   loginPage.setUsername("Dhoni7");
	   loginPage.setPassword("Chennai");
	   loginPage.clickSubmitButton();
	}

	@Then("^'Incorrect Username or password\\.' message should display$")
	public void incorrect_Username_or_password_message_should_display() throws Throwable {
	    String actualErrorMessage = driver.findElement(By.xpath("//*[@id=\"js-flash-container\"]/div")).getText();
	    String expectedErrorMessage = "Incorrect username or password.";
	    Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}

	@When("^User enter valid username and password$")
	public void user_enter_valid_username_and_password() throws Throwable {
	    loginPage.setUsername("Avaneesh12");
	    loginPage.setPassword("avaneesh");
	    loginPage.clickSubmitButton();
	}

	@Then("^User should successfully Signin on his github account$")
	public void user_should_successfully_Signin_on_his_github_account() throws Throwable {
	    
		String actualTitle = driver.getTitle();
		String expectedTitle = "Avaneesh12";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
