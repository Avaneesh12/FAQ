package com.cg.mail.StepDefination;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;

public class Mail_Login_stepDefination 
{
	private WebDriver driver;
	
	@Given("^User is on the homepage$")
	public void user_is_on_the_homepage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
	    driver.get("https://www.google.com/");
	}

	@When("^User navigates to the talent page$")
	public void user_navigates_to_the_talent_page() throws Throwable {
	    driver.get("https://talent.capgemini.com/in");
	}

	@When("^click on webmail$")
	public void click_on_webmail() throws Throwable {
		
	    WebElement mail = driver.findElement(By.linkText("Webmail (On-premise)"));
	    mail.click();
	    
	}

	@When("^enters username and password$")
	public void enters_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	@Then("^Successfull Login page is displayed$")
	public void successfull_Login_page_is_displayed() throws Throwable {
	    WebElement username = driver.findElement(By.id(""));
	    username.sendKeys("avkaushi");
	    
	}


}
