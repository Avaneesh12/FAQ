package com.cg.naukariregister.stepdefinition;
import java.util.ArrayList;
import java.util.Set;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class NaukariRegisterStepDefinition {
private WebDriver driver;
@Given("^user is on homepage of naukari\\.com$")
public void user_is_on_homepage_of_naukari_com() throws Throwable 
{               
		  System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
			driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 driver.get("https://www.naukri.com");
			 Set<String>allWindows=driver.getWindowHandles();
			 ArrayList<String>tabs=new ArrayList<>(allWindows);
			 for(int i=1;i<tabs.size();i++)
			 {
				 
				 driver.switchTo().window(tabs.get(i));
				 driver.close();
			 }
			 driver.switchTo().window(tabs.get(0));
	}

	@When("^user will click on register now$")
	public void user_will_click_on_register_now() throws Throwable 
	{
		
	 driver.findElement(By.linkText("Register Now")).click();
	 Set<String>allWindows=driver.getWindowHandles();
	 ArrayList<String>tabs=new ArrayList<>(allWindows);
	 driver.switchTo().window(tabs.get(1));
	 driver.switchTo().window(tabs.get(0));
	 driver.close();
	 driver.switchTo().window(tabs.get(1));
	 System.out.println(driver.getTitle());
	 
	}

	@Then("^title of page will be Register on Naukri\\.com: Apply to Millions of Jobs Online$")
	public void title_of_page_will_be_Register_on_Naukri_com_Apply_to_Millions_of_Jobs_Online() throws Throwable 
	{
	String title=driver.getTitle();
Assert.assertEquals("Register on Naukri.com: Apply to Millions of Jobs Online", title);
	}

	@When("^user will click on I am a fresher$")
	public void user_will_click_on_I_am_a_fresher() throws Throwable 
	{
		driver.findElement(By.xpath("//button[@title='I am a Fresher']")).click();
		System.out.println(driver.getTitle());
		
	}

	@Then("^title of page will be  Post Resume Online - Submit your CV - Naukri\\.com$")
	public void title_of_page_will_be_Post_Resume_Online_Submit_your_CV_Naukri_com() throws Throwable 
	{
	 String title=driver.getTitle();
    Assert.assertEquals("Resume Manager - Post Resume Online - Submit your CV - Naukri.com", title); 
	}

	@When("^user will fill all the details and click on register now$")
	public void user_will_fill_all_the_details_and_click_on_register_now() throws Throwable 
	{
	   driver.findElement(By.xpath("//input[@id='fname']")).sendKeys("abhinav");
	   driver.findElement(By.xpath("//input[@id='email']")).sendKeys("dj23455we2212p3oyt@yahoo.com");
	   driver.findElement(By.xpath("//input[@name='password']")).sendKeys("pkq1kjfjffj23123@qwea");
	   driver.findElement(By.xpath("//input[@name='number']")).sendKeys("0000091700"); 
	   driver.findElement(By.xpath("//input[@name='city']")).sendKeys("Delhi");
	   driver.findElement(By.xpath("//input[@name='uploadCV']")).sendKeys("D:\\Users\\ADM-IG-HWDLAB1C\\Desktop\\servlets&jsp.txt");
	   driver.findElement(By.xpath("//button[@name='basicDetailSubmit']")).click();
	   
	   WebDriverWait wait=new WebDriverWait(driver,100);
	   wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name("qualification_0")));
		 driver.findElement(By.name("qualification_0")).click();
		 driver.findElement((By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li/div/div/span"))).click();
		 driver.findElement((By.xpath("//input[@name='course_0']"))).sendKeys("Selenium");
		 driver.findElement((By.xpath("//input[@name='spec_0']"))).sendKeys("BDD");
		 driver.findElement((By.xpath("//input[@name='institute_0']"))).sendKeys("Xytz");
		 driver.findElement(By.xpath("//input[@id='couseType_full_0']//following::label[1]")).click();
		 driver.findElement(By.xpath("//input[@name='passingYear_0']")).click();
		 driver.findElement(By.xpath("//input[@name='passingYear_0']//following::li[2]")).click();
		 driver.findElement(By.xpath("//input[@name='keyskills']")).sendKeys("po1kjd");
		 driver.findElement(By.xpath("//button[@type='submit' and @name='submitEducationDetail']")).click();
		 Thread.sleep(10000);
	}
	@Then("^registeration will be successfully done$")
	public void registeration_will_be_successfully_done() throws Throwable 
	{
		String title=driver.getTitle();
	    Assert.assertEquals("Freshers My Naukri", title); 
	    driver.quit();
			}   
	}
	

