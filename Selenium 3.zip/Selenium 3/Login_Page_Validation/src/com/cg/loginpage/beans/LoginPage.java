package com.cg.loginpage.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	@FindBy(how=How.ID,id="uname")
	WebElement userName;
	
	@FindBy(how=How.ID,id="pass")
	WebElement password;
	
	@FindBy(how=How.ID,id="btn")
	WebElement loginButton;

	public String getUserName() {
		return this.userName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public String getPassword() {
		return this.password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	public void clickLoginButton() {
		this.loginButton.click();
	}
	
}
