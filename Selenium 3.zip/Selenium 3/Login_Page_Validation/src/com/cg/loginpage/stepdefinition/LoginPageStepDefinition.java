package com.cg.loginpage.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.loginpage.beans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefinition {

	private WebDriver driver;
	private LoginPage login;
	
	@Before
	public void setupStepEnv() {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
	   
		driver.get("file:D:\\Users\\ADM-IG-HWDLAB1C\\Desktop\\loginform.html");
		login = new LoginPage();
		PageFactory.initElements(driver, login); 
		
	}

	@When("^user clicks on 'login' button leaving username feild blank$")
	public void user_clicks_on_login_button_leaving_username_feild_blank() throws Throwable {
	    
		login.setUserName("");
	    login.clickLoginButton();
	   
	}

	@Then("^'Empty User Name is not allowed' message should be displayed$")
	public void empty_User_Name_is_not_allowed_message_should_be_displayed() throws Throwable {
	    
		String expectedMessage="UserName cannot be empty";
		String actualMessage=driver.switchTo().alert().getText();
		assertEquals(expectedMessage, actualMessage);
	    driver.switchTo().alert().dismiss();
	    
	}

	@When("^user clicks on 'login' button leaving password feild blank$")
	public void user_clicks_on_login_button_leaving_password_feild_blank() throws Throwable {
	    
		login.setUserName("Jason");
		login.setPassword("");
		login.clickLoginButton();
	    
	}

	@Then("^'Password cannot be empty' message should be displayed$")
	public void password_cannot_be_empty_message_should_be_displayed() throws Throwable {
	    
		String expectedMessage="Password cannot be empty";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	    
	}

	@When("^user clicks on 'login' button  using wrong password$")
	public void user_clicks_on_login_button_using_wrong_password() throws Throwable {
	   
		login.setUserName("Takeada");
		login.setPassword("qwerty");
		login.clickLoginButton();
	    
	}

	@Then("^'Password must be (\\d+) characters long' message should be displayed$")
	public void password_must_be_characters_long_message_should_be_displayed(int arg1) throws Throwable {
	    
		String expectedMessage="Password must be 8 characters long";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	    
	}

	@When("^user clicks on 'login' button providing correct credentials$")
	public void user_clicks_on_login_button_providing_correct_credentials() throws Throwable {
	    
		login.setUserName("KungJin");
		login.setPassword("123456789");
		login.clickLoginButton();
	    
	}

	@Then("^'Logged in as userName' message should be displayed$")
	public void logged_in_as_userName_message_should_be_displayed() throws Throwable {
	    
		String expectedMessage="Logged in as KungJin";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().dismiss();
		
		String expectedPageTitle="Welcome Page"; 
		String actualPageTitle=driver.getTitle(); 
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
	    
	}

}
