package com.cg.project.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.BusBooking;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RedbusDefinition {
	
	private WebDriver driver;
	private BusBooking booking;

	@Before(order = 1)
	public void setupStepEnv1() {
		System.out.println("setupStepEnv1");
		System.setProperty("webdriver.chrome.driver", "D:\\\\Chrome\\\\chromedriver.exe");
		driver = new ChromeDriver();
		
	}
	
	
	@Given("^User is on a Redbus site 'www\\.redbus\\.in'$")
	public void user_is_on_a_Redbus_site_www_redbus_in() throws Throwable {
	    driver.get("http://www.redbus.in/");
	    booking=new BusBooking();
	    PageFactory.initElements(driver, booking);
	}

	@When("^user enter all the required details$")
	public void user_enter_all_the_required_details() throws Throwable {
	    booking.setFrom1("Delhi");
	    booking.setTo1("Chandigarh");
	    
	    booking.clickOnwardDate1();
	    booking.clickOnwardDate2();
	    Thread.sleep(600);
	    booking.clickFrom2();
	    Thread.sleep(1100);
	    booking.clickTo2();
	    Thread.sleep(1100);
	   
	    
	    booking.clickSearchBus();
	}

	@Then("^the bus is booked$")
	public void the_bus_is_booked() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
}
