package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BusBooking {
	
	@FindBy(xpath="//*[@id=\"src\"]")
	WebElement from1;
	
	@FindBy(xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")
	WebElement from2;
	
	@FindBy(xpath="//*[@id=\"dest\"]")
	WebElement to1;
	
	@FindBy(xpath="//*[@id=\"search\"]/div/div[2]/div/ul/li[1]")
	WebElement to2;
	
	@FindBy(xpath="//*[@id=\"search\"]/div/div[3]/span")
	WebElement onwardDate1;
	
	@FindBy(xpath="//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[4]/td[3]")
	WebElement onwardDate2;
	
	@FindBy(id="search_btn")
	WebElement searchBuses;
	
	public BusBooking() {
	}
	
	public void setFrom1(String from1) {
		this.from1.sendKeys(from1);
	}
	
	public void clickFrom2() {
		this.from2.click();
	}

	public void setTo1(String to1) {
		this.to1.sendKeys(to1);
	}

	public void clickTo2() {
		this.to2.click();
	}
	
	public void clickOnwardDate1() {
		this.onwardDate1.click();
	}
	
	public void clickOnwardDate2() {
		this.onwardDate2.click();
	}
	
	public void clickSearchBus() {
		this.searchBuses.click();
	}

}
