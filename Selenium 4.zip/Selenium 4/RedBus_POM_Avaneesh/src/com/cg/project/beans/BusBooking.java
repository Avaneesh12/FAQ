package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BusBooking {
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\\\"src\\\"]")
	WebElement source;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")
	WebElement sourceClick;
	
	@FindBy(how = How.XPATH,xpath="//*[@id=\\\"dest\\\"]")
	WebElement dest;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"search\"]/div/div[2]/div/ul/li[1]")
	WebElement destClick;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\\\"search\\\"]/div/div[3]/span")
	WebElement dateClick;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[6]/td[4]")
	WebElement selectDate;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\\\"search_btn\\\"]")
	WebElement searchBus;
	
	public BusBooking() {}
	
	public void setSource(String source) {
		this.source.sendKeys(source);
	}
	
	public void SourceClick() {
		this.sourceClick.click();
	}

	public void setDest(String dest) {
		this.dest.sendKeys(dest);
	}
	
	public void DestClick() {
		this.destClick.click();	}

	
	public void setDateClick() {
		this.dateClick.click();
	}

	
	public void setSelectDate() {
		this.selectDate.click();
	}

	
	public void setSearchBus() {
		this.searchBus.click();
	}
	
	
}
