package com.cg.register.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.register.beans.Register;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class RegisterStepDefinition 
{
	private WebDriver driver;
	private Register register=new Register();
	@Given("^user is on register page$")
	public void user_is_on_register_page() throws Throwable 
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("D:\\Users\\ADM-IG-HWDLAB1C\\Desktop\\Register.html");
		PageFactory.initElements(driver, register); 
	}

	@When("^user will click on submit with empty field$")
	public void user_will_click_on_submit_with_empty_field() throws Throwable 
	{
	    register.submitButton();
	    Thread.sleep(3000);
	    
	}

	@Then("^message comes 'Name cannot be blank'$")
	public void message_comes_Name_cannot_be_blank() throws Throwable {
		Alert alert=driver.switchTo().alert();
	    String actualTitle=alert.getText();
	    String expectedTitle="Name can't be blank";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^user will click on submit$")
	public void user_will_click_on_submit() throws Throwable {
		register.setName("abhinav");
		register.setPassword("coolboy@375");
		register.genderButton();
		register.hobbiesButton();
		register.collegeButton();
		register.submitButton();
		  Thread.sleep(3000);
	 
	}

	@Then("^title of page will be welcome user$")
	public void title_of_page_will_be_welcome_user() throws Throwable {
		String title=driver.getTitle();
		 Assert.assertEquals(title,"Welcome user");
		 driver.close();
	}
	
	
}
