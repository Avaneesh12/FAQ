package com.cg.register.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Register 
{
	@FindBy(how=How.XPATH,xpath="//input[@name='name']")
	WebElement name;
	
     @FindBy(how=How.XPATH,xpath="//input[@name='password']")
 	WebElement password;
     
     @FindBy(how=How.XPATH,xpath="//input[@id='male'] ")
  	WebElement genderButton;
     
     @FindBy(how=How.XPATH,xpath="//input[@id='Singing']")
   	WebElement hobbiesButton;
     
     @FindBy(how=How.XPATH,xpath="//select[@id='college'] //following::option[2]")
    	WebElement collegeButton;
     
     @FindBy(how=How.XPATH,xpath="//input[@value='submit']" )
 	WebElement submitButton;
	
	public Register(){}
	
     public String getName() {
		return this.name.getAttribute("value");
	}
	public void setName(String name) {
		this.name.sendKeys(name);
	}
	public String getPassword() {
		return this.password.getAttribute("value");
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	public void genderButton() {
		genderButton.click();
	}
	public void hobbiesButton() {
		hobbiesButton.click();
	}
	public void collegeButton() {
		collegeButton.click();
	}
	public void submitButton() {
		submitButton.click();
	}
}
