package com.cg.naukri.StepDefination;

import java.util.ArrayList;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Naukri_StepDefination 
{
	private WebDriver driver;
	
	@Given("^User is on the Home page$")
	public void user_is_on_the_Home_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@When("^User navigates to Naukri\\.com$")
	public void user_navigates_to_Naukri_com() throws Throwable {
	    driver.get("https://www.naukri.com/");
	    Set<String> allWindows = driver.getWindowHandles();
	    ArrayList<String> tabs = new ArrayList<>(allWindows);
	    for(int i = 1; i < tabs.size();i++)
	    {
	    	driver.switchTo().window(tabs.get(i));
	    	driver.close();
	    }
	    driver.switchTo().window(tabs.get(0));
	}

	@When("^User clicks on the login button$")
	public void user_clicks_on_the_login_button() throws Throwable {
		WebElement login = driver.findElement(By.className("mTxt"));
	    login.click();
	}

	@When("^clicks on the register now link$")
	public void clicks_on_the_register_now_link() throws Throwable {
	    driver.findElement(By.linkText("Register Now")).click();
	    
	    Set<String> allWindows = driver.getWindowHandles();
	    ArrayList<String> tabs = new ArrayList<>(allWindows);
	    
	    driver.switchTo().window(tabs.get(1));
	   //driver.switchTo().window(tabs.get(0));
	 
	    //sdriver.switchTo().window(tabs.get(1));
	    
	}

	@When("^clicks on I am a fresher$")
	public void clicks_on_I_am_a_fresher() throws Throwable {
		
		driver.findElement(By.name("userType")).click();
	    
	}

	@When("^user enter the details to register$")
	public void user_enter_the_details_to_register() throws Throwable {
	    driver.findElement(By.id("fname")).sendKeys("Avaneesh");;
	    driver.findElement(By.id("email")).sendKeys("hqdjdgvnksdfhfa@gmail.com");
	    driver.findElement(By.name("password")).sendKeys("@A12hello");
	    driver.findElement(By.name("number")).sendKeys("1236547890");
	    driver.findElement(By.name("city")).sendKeys("Bangalore");
	    driver.findElement(By.name("uploadCV")).sendKeys("D:\\Users\\ADM-IG-HWDLAB1C\\Desktop\\servlets&jsp.txt");
	    driver.findElement(By.name("basicDetailSubmit")).click();
	    
	    WebDriverWait wait = new WebDriverWait(driver,300);
	    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.name("qualification_0")));
	    
	    driver.findElement(By.name("qualification_0")).click();
	    driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li/div/div/span")).click();
	    driver.findElement(By.xpath("//input[@name='course_0']")).sendKeys("Selenium");
	    driver.findElement(By.xpath("//input[@name='spec_0']")).sendKeys("Testing");
	    driver.findElement(By.xpath("//input[@name='institute_0']")).sendKeys("fgsxgfabhuhwgfdhef");
	    driver.findElement(By.className("customRadioLbl")).click();
	    driver.findElement(By.name("passingYear_0")).click();
	    driver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/edu-passing/div/div[1]/div/div/div[2]/ul/li[5]")).click();
	    driver.findElement(By.xpath("//input[@name='keyskills']")).sendKeys("djhdhgfghfhfhf");
//	    WebDriverWait wait1 = new WebDriverWait(driver,100);
//	    wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@name='submitEducationDetail' and @class='primary-btn']")));
	    driver.findElement(By.xpath("//button[@name='submitEducationDetail' and @class='primary-btn']")).click();
	}

	@Then("^registration will be successfully done$")
	public void registration_will_be_successfully_done() throws Throwable {
		String title=driver.getTitle();
	    Assert.assertEquals("Freshers My Naukri", title); 
	    driver.quit();
	}

}
