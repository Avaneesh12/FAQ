package com.cg.naukariregister.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class NaukriBeans {

	@FindBy(how=How.LINK_TEXT,linkText="Register Now")
	WebElement RegisterNowButton;
	
	public void registerNowButton() {
		RegisterNowButton.click();
	}
	
	@FindBy(how=How.XPATH,xpath="//button[@title='I am a Fresher']")
	WebElement IamFresherButton;
	
	public void iAmFresherButton() {
		IamFresherButton.click();
	}
	
	@FindBy(how=How.XPATH,xpath="//input[@id='fname']")
	WebElement fresherName;
	
	@FindBy(how=How.XPATH,xpath="//input[@id='email']")
	WebElement fresherEmail;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='password']")
	WebElement fresherpassword;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='number']")
	WebElement freshermobileNo;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='city']")
	WebElement currentLocation;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='uploadCV']")
	WebElement uploadResume;
	
	@FindBy(how=How.XPATH,xpath="//button[@name='basicDetailSubmit']")
	WebElement submitDetailsButton;
	
	@FindBy(how=How.NAME,name="qualification_0")
	WebElement highestQualificationButton;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li/div/div/span")
	WebElement selectHigestQualification;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='course_0']")
	WebElement course;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='spec_0']")
	WebElement specialization;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='institute_0']")
	WebElement college;
	
	@FindBy(how=How.XPATH,xpath="//input[@id='couseType_full_0']//following::label[1]")
	WebElement courseTypeButton;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='passingYear_0']")
	WebElement passingYearbutton;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='passingYear_0']//following::li[2]")
	WebElement selectPassingyearButton;
	
	@FindBy(how=How.XPATH,xpath="//button[@type='submit' and @name='submitEducationDetail']")
	WebElement continueButton;
	
	@FindBy(how=How.XPATH,xpath="//input[@name='keyskills']")
	WebElement skills;
	
	public void highestQualificationButton() {
		highestQualificationButton.click();
	}
	
	public void selectHigestQualification() {
		selectHigestQualification.click();
	}
	
	public void courseTypeButton() {
		courseTypeButton.click();
	}
	
	public void submitDetailsButton() {
		submitDetailsButton.click();
	}
	
	public void passingYearButton() {
		passingYearbutton.click();
	}
	
	public void selectPassingyearButton() {
		selectPassingyearButton.click();
	}
	
	public void continueButton() {
		continueButton.click();
	}

	public String getCourse() {
		return this.course.getAttribute("value");
	}

	public void setCourse(String course) {
		this.course.sendKeys(course);
	}

	public String getSpecialization() {
		return this.specialization.getAttribute("value");
	}

	public void setSpecialization(String specialization) {
		this.specialization.sendKeys(specialization);
	}

	public String getCollege() {
		return this.college.getAttribute("value");
	}

	public void setCollege(String college) {
		this.college.sendKeys(college); 
	}

	public String getSkills() {
		return this.skills.getAttribute("value");
	}

	public void setSkills(String skills) {
		this.skills.sendKeys(skills);
	}

	public String getUploadResume() {
		return this.uploadResume.getAttribute("value");
	}

	public void setUploadResume(String uploadResume) {
		this.uploadResume.sendKeys(uploadResume);
	}

	public String getFresherName() {
		return this.fresherName.getAttribute("value");
	}

	public void setFresherName(String fresherName) {
		this.fresherName.sendKeys(fresherName);
	}

	public String getFresherEmail() {
		return this.fresherEmail.getAttribute("value");
	}

	public void setFresherEmail(String fresherEmail) {
		this.fresherEmail.sendKeys(fresherEmail); 
	}

	public String getFresherpassword() {
		return this.fresherpassword.getAttribute("value");
	}

	public void setFresherpassword(String fresherpassword) {
		this.fresherpassword.sendKeys(fresherpassword);
	}

	public String getFreshermobileNo() {
		return this.freshermobileNo.getAttribute("value");
	}

	public void setFreshermobileNo(String freshermobileNo) {
		this.freshermobileNo.sendKeys(freshermobileNo); 
	}

	public String getCurrentLocation() {
		return this.currentLocation.getAttribute("value");
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation.sendKeys(currentLocation); 
	}
	
}
